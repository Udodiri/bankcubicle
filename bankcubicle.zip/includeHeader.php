<div class="block1 p_bottom_zero">
  <div class="container_12"> 
    <!--==============================header=================================-->
    <header class="homepage" style="dborder:1px solid #fff;">
      <h1 style="dborder:1px solid #000; float:left;"><a class="logo" href="index.php"><img src="images/logo.png" height="32" width="200" /></a></h1>
      <nav style="dborder:1px solid #FF6; margin-top:5px;">
        <ul class="sf-menu">
          <li class="<?php echo $current1;?>"><a href=".\">Home</a></li>
          <li class="<?php echo $current2;?>"><a href="javascript:">About</a>
            <ul>
              <li><a href="the-company">The Company </a></li>
              <li><a href="our-team">Our Team</a></li>
            </ul>
          </li>
          <li class="<?php echo $current3;?>"><a href="services">Services</a></li>
          <li class="<?php echo $current4;?>"><a href="contact">Contact</a></li>
        </ul>
      </nav>
      <div class="clear"></div>
    </header><!--  class="homepage" -->
  </div><!-- container_12 -->
</div><!--  class="block1 p_bottom_zero" -->