<?php
$current1 = $current2 = $current4 = '';
$current3 = 'current'; //currentPage
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include 'includeHTML_HeadTag.php';?>
</head>
<body>

<?php include 'includeHeader.php'; ?>

<div id="smallerBanner">
	<img src="images/services.jpg" />
</div><!-- smallerBanner -->

<div class="block2" style="dborder:1px solid #c00;">
  <div class="container_12" style="dborder:1px solid #000; width:75%;"> 
    <!--==============================content================================-->
    <section class="content" style=" padding:40px 0;">
      <div class="wrapper projects">
        <div class="row clearfix">
          <article class="grid_14" style="dborder:1px solid #000;">
              <div class="wrapper" style="dborder:1px solid #c00;">
              		<article class="grid_6 servicesL" style="dborder:1px solid #000;">
                      <h1 id="services_H1">DAILY MICRO SAVINGS</h1>
                      <p style="font-size:16px; color:#000; margin-top:10px;">
                      	Lorem ipsum dolor sit amet, consect etur adip scing elit. Vestibulum ut tortor urnati dunt dolor. Nunc vulputate ultrices con sect etur donec semper lacinia ultricies. <br /><br />
                        
                        Lorem ipsum dolor sit amet, consect etur adip scing elit. Vestibulum ut tortor urnati dunt dolor. Nunc vulputate ultrices con sect etur donec semper lacinia ultricies. <br /><br />
                        
                        Lorem ipsum dolor sit amet, consect etur adip scing elit. Vestibulum ut tortor urnati dunt dolor. Nunc vulputate
                      </p>
                   	</article>
                    
                    <article class="grid_6 servicesImgR" style="">
                  	 <img src="images/featured-work-2.jpg" style="" />
                  	</article>
                    <div style="clear:both;"></div>
                    
                    <div style="border:1px solid #F4F4F4; width:100%;"></div>
                    
                    <br /><br />
                    <!-- NEXT -->
                    <article class="grid_6 servicesImgL" style="">
                  	 <img src="images/featured-work-1.jpg" style="" />
                  	</article>
                  	
                    <article class="grid_6 servicesR" style="">
                      <h1 id="services_H1">BUSINESS CONSULTING</h1>
                      <p style="font-size:16px; color:#000; margin-top:10px;">
                      	Lorem ipsum dolor sit amet, consect etur adip scing elit. Vestibulum ut tortor urnati dunt dolor. Nunc vulputate ultrices con sect etur donec semper lacinia ultricies. <br /><br />
                        
                        Lorem ipsum dolor sit amet, consect etur adip scing elit. Vestibulum ut tortor urnati dunt dolor. Nunc vulputate ultrices con sect etur donec semper lacinia ultricies. <br /><br />
                        
                        Lorem ipsum dolor sit amet, consect etur adip scing elit. Vestibulum ut tortor urnati dunt dolor. Nunc vulputate
                      </p>
                   	</article>
                    <div style="clear:both;"></div>
                    
                    <div style="border:1px solid #F4F4F4; width:100%;"></div>
                    
                    <br /><br />
                    <!-- NEXT -->
                    <article class="grid_6 servicesL" style="dborder:1px solid #000;">
                      <h1 id="services_H1">DIGITAL FINANCIAL SERVICES</h1>
                      <p style="font-size:16px; color:#000; margin-top:10px;">
                      	Lorem ipsum dolor sit amet, consect etur adip scing elit. Vestibulum ut tortor urnati dunt dolor. Nunc vulputate ultrices con sect etur donec semper lacinia ultricies. <br /><br />
                        
                        Lorem ipsum dolor sit amet, consect etur adip scing elit. Vestibulum ut tortor urnati dunt dolor. Nunc vulputate ultrices con sect etur donec semper lacinia ultricies. <br /><br />
                        
                        Lorem ipsum dolor sit amet, consect etur adip scing elit. Vestibulum ut tortor urnati dunt dolor. Nunc vulputate
                      </p>
                   	</article>
                    
                    <article class="grid_6 servicesImgR" style="">
                  	 <img src="images/featured-work.jpg" style="" />
                  	</article>
                    <div style="clear:both;"></div>
               </div><!-- wrapper -->
          </article>
        </div><!-- class="row clearfix" -->
        
      </div>
    </section>
  </div>
</div>

<?php include 'includeFooter.php';?>
</body>
</html>